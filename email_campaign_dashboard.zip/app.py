#!/usr/bin/env python3
"""
Advanced Email Campaign Dashboard - No Tracking
- Multiple email providers (Gmail, Zoho, Outlook, etc.)
- Multiple templates - rotates every 3 emails
- Follow-up sequences with delays
- Batch splitting (send 5, pause, change subject)
- STOP/START/RESUME campaign buttons
- Random sleep between emails to avoid spam detection
"""

from flask import Flask, render_template, request, jsonify
import smtplib
from email.mime.text import MIMEText
import csv
from io import StringIO
import json
import os
from datetime import datetime, timedelta
import threading
import time
import random

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

campaigns = {}

# Email provider configs
EMAIL_PROVIDERS = {
    'gmail': {
        'smtp_server': 'smtp.gmail.com',
        'smtp_port': 587,
        'name': 'Gmail'
    },
    'zoho': {
        'smtp_server': 'smtp.zoho.com',
        'smtp_port': 587,
        'name': 'Zoho Mail'
    },
    'outlook': {
        'smtp_server': 'smtp.office365.com',
        'smtp_port': 587,
        'name': 'Outlook/Office365'
    },
    'yahoo': {
        'smtp_server': 'smtp.mail.yahoo.com',
        'smtp_port': 587,
        'name': 'Yahoo Mail'
    },
    'sendgrid': {
        'smtp_server': 'smtp.sendgrid.net',
        'smtp_port': 587,
        'name': 'SendGrid'
    }
}

def find_column(available_cols, possible_names):
    """Find column by case-insensitive matching"""
    for col in available_cols:
        if col.lower().strip() in [p.lower().strip() for p in possible_names]:
            return col
    return None

class EmailCampaign:
    def __init__(self, campaign_id, name, sender_email, app_password, provider, leads, templates, 
                 subject_lines, follow_ups, batch_size=5, template_split_count=3):
        self.campaign_id = campaign_id
        self.name = name
        self.sender_email = sender_email
        self.app_password = app_password
        self.provider = provider
        self.leads = leads
        self.templates = templates
        self.subject_lines = subject_lines
        self.follow_ups = follow_ups
        self.batch_size = batch_size
        self.template_split_count = template_split_count
        
        self.status = 'pending'
        self.current_batch = 0
        self.sent = 0
        self.failed = 0
        self.total = len(leads)
        self.results = []
        self.created_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.scheduled_followups = []
        self.followups_stopped = False
        self.should_stop = False
        
    def get_smtp_config(self):
        """Get SMTP config for provider"""
        config = EMAIL_PROVIDERS.get(self.provider.lower())
        if not config:
            config = EMAIL_PROVIDERS['gmail']
        return config
        
    def personalize_template(self, template_text, business_name, location):
        """Replace placeholders in template"""
        city = location.split(',')[-1].strip() if ',' in location else location
        template_text = template_text.replace('[Business Name]', business_name)
        template_text = template_text.replace('[City]', city)
        template_text = template_text.replace('[Location]', location)
        return template_text

    def get_subject_line(self, index):
        """Get subject line for email index (round-robin)"""
        if not self.subject_lines:
            return "You're losing ~$7K/mo on Google (not an exaggeration)*"
        return self.subject_lines[index % len(self.subject_lines)]
    
    def get_template(self, email_index):
        """Get template by email index - rotates every N emails"""
        if not self.templates:
            return ""
        
        template_idx = (email_index // self.template_split_count) % len(self.templates)
        return self.templates[template_idx]['content']

    def send_email(self, lead, template_text, subject_line, server):
        """Send single email"""
        try:
            business_name = lead.get('Business Name', 'there').strip()
            email = lead.get('Email', '').strip()
            location = lead.get('Location', '').strip()

            if not email:
                return False, 'No email provided'

            msg = MIMEText('')
            msg['From'] = self.sender_email
            msg['To'] = email
            msg['Subject'] = subject_line

            body = self.personalize_template(template_text, business_name, location)
            msg.set_payload(body)
            
            server.send_message(msg)
            return True, None
            
        except Exception as e:
            return False, str(e)

    def send_batch(self):
        """Send one batch of emails"""
        if self.should_stop:
            self.status = 'stopped'
            return

        config = self.get_smtp_config()
        smtp_server = config['smtp_server']
        smtp_port = config['smtp_port']

        try:
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(self.sender_email, self.app_password)
            print(f"[BATCH] Connected to {config['name']}")

            start_idx = self.current_batch * self.batch_size
            end_idx = min(start_idx + self.batch_size, self.total)

            for idx in range(start_idx, end_idx):
                if self.should_stop:
                    self.status = 'stopped'
                    server.quit()
                    return

                lead = self.leads[idx]
                subject_line = self.get_subject_line(idx)
                template_text = self.get_template(idx)
                
                success, error = self.send_email(lead, template_text, subject_line, server)
                
                # Random sleep between emails to avoid spam detection
                if idx < end_idx - 1:
                    # Randomize sleep time: 25-45 seconds, sometimes up to 60 seconds
                    if random.random() < 0.2:  # 20% chance of longer delay
                        sleep_time = random.uniform(45, 65)
                    else:
                        sleep_time = random.uniform(25, 45)
                    print(f"[SLEEP] Waiting {sleep_time:.1f}s before next email to avoid spam...")
                    time.sleep(sleep_time)
                
                if success:
                    self.sent += 1
                    template_num = (idx // self.template_split_count) % len(self.templates) + 1
                    
                    self.results.append({
                        'email': lead.get('Email', ''),
                        'business_name': lead.get('Business Name', ''),
                        'status': 'sent',
                        'subject': subject_line,
                        'template': f'Template {template_num}',
                        'batch': self.current_batch + 1,
                        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    })
                    print(f"[SUCCESS] Email sent to {lead.get('Email', '')}")
                else:
                    self.failed += 1
                    self.results.append({
                        'email': lead.get('Email', ''),
                        'status': 'failed',
                        'reason': error,
                        'batch': self.current_batch + 1
                    })
                    print(f"[FAILED] {error}")

            server.quit()
            self.current_batch += 1
            
            # Schedule follow-ups for this batch
            if self.follow_ups and not self.followups_stopped:
                self.schedule_followups(start_idx, end_idx)
            
            # Check if more batches
            if self.current_batch * self.batch_size < self.total:
                self.status = 'paused'
                print(f"[BATCH] Paused after batch {self.current_batch}")
            else:
                self.status = 'completed'
                print(f"[BATCH] Campaign completed")

        except smtplib.SMTPAuthenticationError:
            self.status = 'failed'
            print(f"[ERROR] Authentication failed for {self.provider}")
            self.results.append({
                'status': 'error',
                'reason': 'Authentication failed. Check email/password.'
            })
        except Exception as e:
            self.status = 'failed'
            print(f"[ERROR] Exception: {str(e)}")
            self.results.append({
                'status': 'error',
                'reason': str(e)
            })

    def schedule_followups(self, batch_start, batch_end):
        """Schedule follow-up emails for this batch"""
        for fu_idx, followup in enumerate(self.follow_ups):
            days = followup.get('days', fu_idx + 1)
            scheduled_time = datetime.now() + timedelta(days=days)
            
            for lead_idx in range(batch_start, batch_end):
                self.scheduled_followups.append({
                    'lead_idx': lead_idx,
                    'scheduled_time': scheduled_time,
                    'followup_idx': fu_idx,
                    'status': 'pending'
                })

    def send_scheduled_followups(self):
        """Check and send scheduled follow-ups"""
        if self.followups_stopped:
            return

        now = datetime.now()
        config = self.get_smtp_config()
        smtp_server = config['smtp_server']
        smtp_port = config['smtp_port']
        
        pending = [f for f in self.scheduled_followups if f['status'] == 'pending']
        due = [f for f in pending if f['scheduled_time'] <= now]
        
        if not due:
            return
        
        try:
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(self.sender_email, self.app_password)

            for followup in due:
                if self.followups_stopped:
                    break

                lead = self.leads[followup['lead_idx']]
                fu_data = self.follow_ups[followup['followup_idx']]
                
                template_text = fu_data.get('template', '')
                subject_line = fu_data.get('subject', 'Follow-up')
                
                success, error = self.send_email(lead, template_text, subject_line, server)
                followup['status'] = 'sent' if success else 'failed'
                
                result = {
                    'email': lead.get('Email', ''),
                    'business_name': lead.get('Business Name', ''),
                    'status': 'sent' if success else 'failed',
                    'subject': subject_line,
                    'type': f'followup_{followup["followup_idx"] + 1}',
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                if error:
                    result['reason'] = error
                self.results.append(result)

            server.quit()
        except Exception as e:
            print(f"[ERROR] Error sending follow-ups: {e}")

    def stop_campaign(self):
        """Stop current campaign"""
        self.should_stop = True
        self.status = 'stopped'

    def resume_campaign(self):
        """Resume a stopped campaign"""
        if self.status == 'stopped':
            self.should_stop = False
            self.status = 'running'
            return True
        return False

    def stop_followups(self):
        """Stop all scheduled follow-ups"""
        self.followups_stopped = True


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/campaigns', methods=['GET'])
def get_campaigns():
    return jsonify({
        'campaigns': [
            {
                'id': cid,
                'name': c.name,
                'status': c.status,
                'sent': c.sent,
                'failed': c.failed,
                'total': c.total,
                'current_batch': c.current_batch,
                'batches_total': (c.total + c.batch_size - 1) // c.batch_size,
                'created_at': c.created_at,
                'followups_stopped': c.followups_stopped,
                'provider': c.provider
            }
            for cid, c in campaigns.items()
        ]
    })

@app.route('/api/campaigns/<campaign_id>', methods=['GET'])
def get_campaign(campaign_id):
    if campaign_id not in campaigns:
        return jsonify({'error': 'Campaign not found'}), 404

    c = campaigns[campaign_id]
    return jsonify({
        'id': campaign_id,
        'name': c.name,
        'status': c.status,
        'sent': c.sent,
        'failed': c.failed,
        'total': c.total,
        'current_batch': c.current_batch,
        'results': c.results[-100:],
        'created_at': c.created_at,
        'followups_stopped': c.followups_stopped
    })

@app.route('/api/campaigns/<campaign_id>/resume', methods=['POST'])
def resume_campaign(campaign_id):
    if campaign_id not in campaigns:
        return jsonify({'error': 'Campaign not found'}), 404

    campaign = campaigns[campaign_id]
    
    if campaign.status == 'paused':
        campaign.status = 'running'
        thread = threading.Thread(target=campaign.send_batch)
        thread.daemon = True
        thread.start()
        return jsonify({'success': True, 'message': 'Campaign resumed from pause'})
    
    elif campaign.status == 'stopped':
        if campaign.resume_campaign():
            thread = threading.Thread(target=campaign.send_batch)
            thread.daemon = True
            thread.start()
            return jsonify({'success': True, 'message': 'Campaign restarted from stop'})
        else:
            return jsonify({'error': 'Cannot resume from this status'}), 400
    
    else:
        return jsonify({'error': f'Campaign is {campaign.status}. Cannot resume.'}), 400

@app.route('/api/campaigns/<campaign_id>/stop', methods=['POST'])
def stop_campaign(campaign_id):
    if campaign_id not in campaigns:
        return jsonify({'error': 'Campaign not found'}), 404

    campaign = campaigns[campaign_id]
    campaign.stop_campaign()

    return jsonify({
        'success': True,
        'message': 'Campaign stopped',
        'status': campaign.status
    })

@app.route('/api/campaigns/<campaign_id>/stop-followups', methods=['POST'])
def stop_followups(campaign_id):
    if campaign_id not in campaigns:
        return jsonify({'error': 'Campaign not found'}), 404

    campaign = campaigns[campaign_id]
    campaign.stop_followups()

    return jsonify({
        'success': True,
        'message': 'Follow-ups stopped',
        'followups_stopped': campaign.followups_stopped
    })

@app.route('/api/upload-leads', methods=['POST'])
def upload_leads():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    try:
        leads = []
        
        if file.filename.endswith('.csv'):
            file.seek(0)
            stream = StringIO(file.read().decode('utf-8'))
            reader = csv.DictReader(stream)
            leads = list(reader)
        elif file.filename.endswith(('.xlsx', '.xls')):
            try:
                import openpyxl
                wb = openpyxl.load_workbook(file.stream)
                ws = wb.active
                rows = list(ws.iter_rows(values_only=True))
                headers = [str(h).strip() if h else '' for h in rows[0]]
                leads = [
                    {headers[i]: str(val).strip() if val else '' for i, val in enumerate(row)}
                    for row in rows[1:]
                ]
            except ImportError:
                return jsonify({'error': 'Excel support requires: pip install openpyxl'}), 400
        else:
            return jsonify({'error': 'Unsupported format. Use .csv or .xlsx'}), 400

        if not leads:
            return jsonify({'error': 'File is empty'}), 400

        available_cols = list(leads[0].keys())
        
        business_col = find_column(available_cols, ['Business Name', 'business name', 'company', 'name'])
        email_col = find_column(available_cols, ['Email', 'email', 'e-mail', 'mail', 'address'])
        location_col = find_column(available_cols, ['Location', 'location', 'city', 'address'])
        
        if not business_col or not email_col:
            return jsonify({
                'error': f'Cannot find Business Name and/or Email columns. Available: {", ".join(available_cols)}',
                'available_columns': available_cols
            }), 400
        
        if not location_col:
            location_col = None

        leads = [
            {
                'Business Name': str(lead.get(business_col, '')).strip(),
                'Email': str(lead.get(email_col, '')).strip(),
                'Location': str(lead.get(location_col, '')) if location_col else 'Unknown'
            }
            for lead in leads if lead.get(email_col, '').strip()
        ]

        if not leads:
            return jsonify({'error': 'No valid leads found with email addresses'}), 400

        return jsonify({
            'success': True,
            'lead_count': len(leads),
            'leads': leads
        })

    except Exception as e:
        return jsonify({'error': f'Upload error: {str(e)}'}), 400

@app.route('/api/send-campaign', methods=['POST'])
def send_campaign():
    data = request.json

    errors = []
    if not data.get('name'):
        errors.append('Campaign name required')
    if not data.get('sender_email'):
        errors.append('Email address required')
    if not data.get('app_password'):
        errors.append('App password required')
    if not data.get('provider'):
        errors.append('Email provider required')
    if not data.get('templates'):
        errors.append('At least one template required')
    if not data.get('leads') or len(data.get('leads', [])) == 0:
        errors.append('Leads required')

    if errors:
        return jsonify({'errors': errors}), 400

    campaign_id = f"campaign_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    campaign = EmailCampaign(
        campaign_id,
        data['name'],
        data['sender_email'],
        data['app_password'],
        data['provider'],
        data['leads'],
        data.get('templates', []),
        data.get('subject_lines', []),
        data.get('follow_ups', []),
        batch_size=5,
        template_split_count=3
    )

    campaigns[campaign_id] = campaign
    campaign.status = 'running'

    thread = threading.Thread(target=campaign.send_batch)
    thread.daemon = True
    thread.start()

    print(f"[CAMPAIGN] New campaign started: {campaign_id}")

    return jsonify({
        'success': True,
        'campaign_id': campaign_id,
        'message': 'Campaign started - 5 emails per batch, random 35-40s sleep between emails'
    })

@app.route('/api/preview', methods=['POST'])
def preview_email():
    data = request.json
    template = data.get('template', '')
    template = template.replace('[Business Name]', 'Acme Corp')
    template = template.replace('[City]', 'New York')
    template = template.replace('[Location]', '123 Main St, New York')

    return jsonify({'preview': template})

# Background thread for follow-ups
def followup_scheduler():
    while True:
        try:
            for campaign in campaigns.values():
                if campaign.status != 'stopped' and not campaign.followups_stopped:
                    campaign.send_scheduled_followups()
            time.sleep(60)
        except Exception as e:
            print(f"[ERROR] Scheduler error: {e}")

scheduler = threading.Thread(target=followup_scheduler)
scheduler.daemon = True
scheduler.start()

if __name__ == '__main__':
    print("[SERVER] Starting Email Campaign Dashboard...")
    print("[MODE] Email sending with anti-spam delays (2-8s between emails)")
    print("[INFO] Follow-ups run in background scheduler - they continue even if browser is closed")
    app.run(debug=True, port=5000)